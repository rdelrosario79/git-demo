package com.nba.test;

import com.nba.base.BaseTest;
import com.nba.pageObject.nbaHomePage;
import org.testng.Assert;
import org.testng.annotations.Test;


public class nbaHomePageTest extends BaseTest {

    @Test
    public void homePageTests(){
        nbaHomePage nbaPage = new nbaHomePage(getDriver());

        Assert.assertTrue(nbaPage
                .clickOnSignInBtn()
                .clickOnSignInToNBAAccount()
                .setUserAndPassword("rrosario@nba.com", "13301330")
                .NBALogoVisibility());
    }




}
