package com.nba.pageObject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class nbaSchedulePage {
    @FindBy(id="" ) WebElement sample;
}
